# v9 training note

Additional training was run from the v8 database with target 3 and default-index ±10% specialties prioritized. The accepted database favors actual stable success over fastest arrival.

Representative training command used during candidate search:

```bash
python3 train_ai.py --episodes 80 --targets 3 \
  --specialties default_index10_state3,low_acc,low_acc_high_friction,windy \
  --validate-episodes 0 --seconds 12 --save-every 80 --seed 12345 \
  --hard-mining-rate 0.20 --hard-pool-episodes 32 --hard-probes 4
```

Final acceptance was based on actual JavaScript replay, not this trainer score alone.
