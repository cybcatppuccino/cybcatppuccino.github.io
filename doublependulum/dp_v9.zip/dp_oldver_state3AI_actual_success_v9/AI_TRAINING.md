# AI training / replay notes - v5

v5 is an actual-model integration update rather than a new browser-side online trainer.

The static training database is still loaded from:

- `ai_data/training_db.json`

Browser online learning remains disabled so the shipped version uses the packaged learned results deterministically.

The important v5 change is how the learned result is used by the real controller:

- learned phase rules are retained and applied;
- broad learned brake and edge overlays are disabled in the state-3 special branch after actual replay showed they reduced strict stable success;
- validation uses `actual_model_eval.mjs`, not a purely theoretical Python score.

To reproduce the actual-model test:

```bash
node actual_model_eval.mjs --episodes 10 --seed 221 --seconds 15
```
