# AI / Controller Changes in V7

Base: `dp_oldver_state3AI_actual_success_v6`.

## What changed

V7 adds a target3 remote-arrival improvement before final capture:

1. When target is state 3 and the current state is close to state 2 with low
   angular speed, the controller starts a stronger deterministic escape pulse.
2. The escape duration is lengthened only for this source2->state3 situation.
3. The wrong-equilibrium detector for target3 now recognizes low-speed state2
   starts earlier, instead of waiting until the state is almost exactly stuck.

## What did not change

- The V6 terminal low-energy state3 stabilizer is preserved.
- Learned phase advice from `training_db.json` is still used.
- Broad learned brake/edge overlays remain disabled in the final capture stage.
- Non-state3 targets and out-of-range parameters still follow the oldver/v6 path.

## Rejected combinations

The following candidates were tested and rejected:

- Broad remote escape for state0/state1/state2: hurt low-state0 and legacy tests.
- Symmetric one-link bridge for state1 and state2: over-pumped some medium-random
  cases and reduced focused success.
- Aggressive remote blend after every far CEM plan: improved capture speed in
  a few samples but reduced strict stable success.
