# v9 AI/controller changes

## Main accepted change

Added a reserve-preserving two-pulse escape for low-energy state0→state3 starts.

Previous behavior used a single one-sided escape kick. That could successfully add energy, but in some low-energy departures it spent too much support travel before the rods entered a controllable state3 approach. v9 keeps the first kick, then briefly reverses the escape pulse late in the launch. This preserves rail reserve and lets the existing v7/v8 state3 approach logic take over from a better support position.

## Training database

The static `ai_data/training_db.json` was updated with additional state3 success-focused training over the default-index ±10% range. The update is still browser-static: no online browser training and no player physics parameters are modified.

## Preserved from previous builds

- v7 state2→state3 remote bridge.
- v8 conservative coherent state0 bridge idea.
- v6/v7/v8 state3 low-energy terminal stabilizer.
- Learned phase advice from `ai_learning.js`.
- Default oldver path outside target=3 and default-index ±10% range.

## Still intentionally not used

- Broad learned brake overlay as a final authority replacement.
- Broad learned edge overlay as a final authority replacement.
- Forced global collinearity before every state3 approach.
- Rewriting oldver non-state3 behavior.
