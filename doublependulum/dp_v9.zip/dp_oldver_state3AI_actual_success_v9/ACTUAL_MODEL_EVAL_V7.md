# Actual Model Evaluation - V7 Remote Arrival

This evaluation uses the real JavaScript controller and physics implementation:

- `js/controller.js`
- `js/physics.js`
- `js/ai_learning.js`
- `ai_data/training_db.json`

The new V7 test mix emphasizes the problem requested in this iteration: getting
to state 3 from far, low-energy or medium-random starts. It includes:

- low-speed state 0 starts
- low-speed state 1 starts
- low-speed state 2 starts
- medium-speed random starts
- near-state3 regression starts

## Accepted V7 change

V7 adds a narrowly gated remote-arrival escape for target 3 when the system is
close to state 2 with low angular speed. This was the weakest bucket in the V6
focused replay. The change is deliberately not applied to all remote states,
because broader kicks improved some remote cases but harmed existing successes.

## Focused remote-start replay, seed 7001, 30 episodes

| Version | Success rate | Capture rate | Mean stable time | Mean first capture | Edge-risk rate |
|---|---:|---:|---:|---:|---:|
| V6 baseline | 66.7% | 93.3% | 7.435s | 4.846s | 33.3% |
| V7 accepted | 73.3% | 96.7% | 7.393s | 4.336s | 26.7% |

Main bucket improvement:

| Bucket | V6 success | V7 success | V6 first capture | V7 first capture |
|---|---:|---:|---:|---:|
| low-state2 | 55.6% | 77.8% | 5.569s | 3.847s |

## Legacy actual-model regression replay, seed 7001, 30 episodes

| Version | Success rate | Capture rate | Mean stable time | Mean first capture |
|---|---:|---:|---:|---:|
| V6 baseline | 76.7% | 100.0% | 7.262s | 3.860s |
| V7 accepted | 76.7% | 100.0% | 7.717s | 3.895s |

## Original actual-model replay, seed 80807, 20 episodes

| Version | Success rate | Mean stable time | Mean first capture | Edge-risk rate |
|---|---:|---:|---:|---:|
| V6 baseline | 55.0% | 6.425s | 3.410s | 45.0% |
| V7 accepted | 55.0% | 6.425s | 3.410s | 45.0% |

## Interpretation

V7 does not try to retune the already successful terminal state3 stabilizer.
It improves the remote-arrival phase for a weak low-energy bucket, especially
state2-to-state3 starts, while keeping the old V6 route for cases where V6 was
already reliable.
