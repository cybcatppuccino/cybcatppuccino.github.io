# v8 changes — coherent remote arrival for target state 3

This version continues from v7 and keeps the target-state-3 specialization limited to the default index ±10% parameter window.

## Accepted code changes

1. **Coherent low-energy source0 bridge**
   - When target is state 3 and the system is near low-energy state 0, v8 can start a remote escape earlier than v7.
   - This trigger is additionally gated by link coherence:
     - `abs(angleError(th1, th2)) < 0.78`
     - `abs(om1 - om2) < 1.35`
   - This matches the observed useful trick: if both rods already have similar direction and angular velocity, use that coherent geometry to leave state0 toward state3.

2. **Preserved v7 state2 bridge**
   - The existing state2 → state3 remote bridge remains unchanged.
   - It was still the best actual-model option for the lambda-to-upright basin.

3. **Preserved v6/v7 terminal stabilizer**
   - The local state3 low-energy stabilizer, learned phase advice, and reduced broad-brake overlay from v5/v6 are not replaced.
   - v8 only tries to improve the phase before the system reaches state3 capture.

## Rejected candidates

The following variants were tested in actual `controller.js + physics.js` replay but were not accepted:

- Strong collinearity penalty in the CEM score.
- Forced collinear bridge for both state1 and state2 anti-aligned poses.
- Direct source0 coherent-lift acceleration replacing the existing escape pulse.
- Broad sync-preserving score applied to all remote states.

These variants often looked reasonable theoretically, but actual replay showed regressions on state1, state2, or near-state3 cases. The final v8 therefore uses a conservative coherence-gated trigger instead of forcing all trajectories to become collinear.
