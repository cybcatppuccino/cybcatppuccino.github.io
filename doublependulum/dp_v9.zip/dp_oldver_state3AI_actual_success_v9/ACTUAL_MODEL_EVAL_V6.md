# ACTUAL_MODEL_EVAL_V6

This version was accepted using actual JavaScript model replay rather than the Python training proxy alone.

Replay stack:
- `js/controller.js`
- `js/physics.js`
- `js/ai_learning.js`
- `ai_data/training_db.json`
- `actual_model_eval.mjs`

Scope:
- target state: `3`
- default `index.html` parameter range +/- 10% of the total slider axis:
  - `maxAcc`: 14.1 to 25.9
  - `g`: 7.8 to 10.2
  - `windAmp`: 0 to 0.13
  - `friction`: 0 to 0.13

Strict stable condition used by the replay harness:
- angle norm `< 0.34`
- angular speed norm `< 1.20`
- edge ratio `< 0.90`
- normalized positive energy excess `< 0.16`
- the condition must persist for more than 0.36 s.

## Accepted multi-seed replay comparison

The accepted candidate was compared against v5 on 100 actual replay episodes:

Seed/episode set:
- seeds `101, 202, 303, 404, 808`: 12 episodes each
- seeds `505, 606, 707, 909`: 10 episodes each

| version | episodes | strict stable successes | strict success rate | weighted mean stable time among successes |
|---|---:|---:|---:|---:|
| v5 actual-success | 100 | 60 | 60.0% | 7.52 s |
| v6 accepted | 100 | 71 | 71.0% | 7.46 s |

Interpretation:
- The accepted v6 strategy improved strict real-model success by +11 percentage points on this multi-seed replay set.
- Mean stable time among successful episodes did not worsen; it was slightly lower in this suite.
- Capture rate stayed high; most remaining failures are capture-only or rail-edge cases that still enter the target-3 neighborhood but fail the strict low-energy dwell requirement.

## Strategy candidates tested and rejected

Rejected candidates included:

1. Early heavy edge protection: reduced strict success because it pushed already-captured states out of the basin.
2. Broad adaptive brake/edge overlays: same issue as v4; too conservative in the terminal phase.
3. Quiet terminal recentering: helped a few edge cases but reduced success elsewhere.
4. Dual soft/aggressive LQR switching: too sensitive to runtime gating and did not beat the accepted aggregate.

## Accepted strategy

The final v6 accepts a targeted terminal-stability upgrade:
- stronger target-3 angular-rate LQR weighting in the dedicated default-range controller,
- increased terminal alignment / energy-damping mix,
- wider target-3 local-capture activation so the verified local stabilizer takes over earlier,
- conditional rollback of the aggressive LQR weights for low-authority windy/frictional subcases where actual replay showed the older terminal gain is safer,
- continued v5 rule that learned phase advice is retained but broad learned brake/edge overlays are not allowed to dominate the terminal controller.
