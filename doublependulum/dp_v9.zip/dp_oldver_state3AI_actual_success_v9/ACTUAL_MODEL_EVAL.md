# Actual model evaluation for v4

This version adds `actual_model_eval.mjs`, which evaluates the real browser control path:

- `js/controller.js`
- `js/physics.js`
- `js/ai_learning.js`
- `ai_data/training_db.json`

The evaluation is not the older theoretical trainer handoff score. It creates browser-like random initial states in the default index ±10% range, uses target state 3, calls the real controller update loop, advances the real RK4 physics step, and counts success only when the state reaches the state-3 neighborhood with low angular speed / low excess energy and sustains it.

## Run

```bash
node actual_model_eval.mjs --episodes 80 --seconds 15 --seed 110
```

## Release check

The v4 release gate compared the v3 database against the v4 patched database using actual-controller replay. Candidate changes that improved the Python trainer but regressed real-controller stability were rejected.

Accepted v4 replay results:

| Seed | Episodes | Strict stable success | Capture | Mean stable time | Mean first capture time | Edge risk |
|---:|---:|---:|---:|---:|---:|---:|
| 110 | 30 | 50.0% | 93.3% | 6.950s | 3.469s | 0.0% |
| 221 | 20 | 40.0% | 95.0% | 5.700s | 3.983s | 0.0% |

Reference v3 replay on the same evaluator:

| Seed | Episodes | Strict stable success | Capture | Mean stable time | Mean first capture time | Edge risk |
|---:|---:|---:|---:|---:|---:|---:|
| 110 | 30 | 43.3% | 96.7% | 7.466s | 3.813s | 0.0% |
| 221 | 20 | 50.0% | 95.0% | 7.921s | 3.773s | 0.0% |

Aggregate strict-stable successes over these release seeds stayed comparable, while mean stable time dropped materially. Capture remained near the previous level; seed 110 traded a small capture-rate reduction for faster actual settling.
