# Actual model evaluation - v5 actual-success integration

This version focuses on increasing real-model strict stable success, rather than minimizing average stable time at all costs.

## What changed from v4

Actual replay showed that the v4 controller usually entered the target-3 capture region, but the broad learned brake and edge-reserve overlays were too conservative in the real JavaScript controller. Many runs reached a good state-3 neighborhood, then failed to remain there long enough to count as strict stable.

v5 therefore uses the learned database differently:

- keep `adaptiveAI.getPhaseAdvice(...)` and the learned phase-rule policy;
- disable the broad learned `adaptiveCaptureBrakeAcceleration(...)` overlay in the state-3 special branch;
- disable the broad learned `adaptiveEdgeReserveAcceleration(...)` overlay in the state-3 special branch;
- keep a smaller hard-endpoint guard only when the support is already near the rail and moving outward.

This makes the existing learned phase rules work with the real LQR/MPC controller instead of fighting it during final capture.

## Validation method

Command pattern:

```bash
node actual_model_eval.mjs --episodes 10 --seed <seed> --seconds 15
```

The evaluator directly imports and runs:

- `js/controller.js`
- `js/physics.js`
- `js/ai_learning.js`
- `ai_data/training_db.json`

Strict stable condition remains unchanged from v4: state 3 neighborhood, low angular speed, low kinetic/energy proxy, inside the support boundary, and maintained for the required dwell interval.

## 7-seed replay comparison

| Version | Seeds | Episodes | Strict stable successes | Success rate | Mean stable time among successes |
|---|---:|---:|---:|---:|---:|
| v4 actual | 110, 221, 40421, 777, 888, 1357, 2468 | 70 | 24 | 34.3% | ~7.70 s |
| v5 actual-success | 110, 221, 40421, 777, 888, 1357, 2468 | 70 | 50 | 71.4% | ~6.99 s |

## v5 per-seed replay summary

| Seed | Episodes | Success | Capture | Mean stable time | Mean first capture time | Edge-risk rate |
|---:|---:|---:|---:|---:|---:|---:|
| 110 | 10 | 60% | 100% | 4.888 s | 3.108 s | 30% |
| 221 | 10 | 90% | 100% | 5.996 s | 2.735 s | 10% |
| 40421 | 10 | 90% | 100% | 8.090 s | 3.601 s | 30% |
| 777 | 10 | 70% | 100% | 9.714 s | 4.109 s | 40% |
| 888 | 10 | 60% | 100% | 6.540 s | 2.894 s | 70% |
| 1357 | 10 | 70% | 100% | 6.750 s | 2.443 s | 10% |
| 2468 | 10 | 60% | 100% | 6.500 s | 2.327 s | 50% |

## Trade-off

v5 deliberately accepts a higher edge-risk flag than v4 because the requested optimization target is actual success rate. The edge-risk flag is conservative: it marks any episode that approaches the rail while moving outward, even if the episode later achieves strict stable state 3. The hard endpoint guard still prevents uncontrolled endpoint pushing, but v5 no longer lets the broad edge overlay dominate the final state-3 stabilization.
