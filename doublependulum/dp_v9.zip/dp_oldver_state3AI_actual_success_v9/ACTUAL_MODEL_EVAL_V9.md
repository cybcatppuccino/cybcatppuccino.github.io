# v9 actual-model evaluation

This build was selected using actual JavaScript model replay, not only Python trainer scores.
The replay directly uses:

- `js/controller.js`
- `js/physics.js`
- `js/ai_learning.js`
- `ai_data/training_db.json`

Target remains **state 3 only** inside the default index ±10% parameter range.

## Accepted v9 strategy

v9 keeps the v8 remote-arrival architecture, then adds a reserve-preserving state0 escape pulse and a small accepted database update.

The new state0 escape is not a global forced-collinearity controller. It only changes the low-energy state0→state3 departure pattern: the first pulse injects motion, and the short return pulse preserves support reserve so the controller reaches the state3 basin with less wasted rail displacement.

## Actual focused replay

Scenario mix: low-speed state0/state1/state2, mid-random, near-state3.
Seeds: `70421, 81131, 424242, 110, 221`.
Episodes: 50 total.

| Version | Success rate | Capture rate | Mean stable time | Edge-risk rate |
|---|---:|---:|---:|---:|
| v8 | 70.0% | 98.0% | 7.253s | 26.0% |
| v9 accepted | **74.0%** | 98.0% | 7.623s | 36.0% |

Mode detail for v9 accepted:

| Mode | Success rate | Capture rate | Mean stable time |
|---|---:|---:|---:|
| low-state0 | 75.0% | 100.0% | 6.827s |
| low-state1 | 60.0% | 100.0% | 7.327s |
| low-state2 | 76.9% | 100.0% | 6.418s |
| mid-random | 72.7% | 90.9% | 8.197s |
| near-state3 | 87.5% | 100.0% | 9.625s |

## Broader replay

Scenario mix: same focused mix, but expanded to more seeds.
Seeds: `70421, 81131, 424242, 110, 221, 13579, 60606, 99991, 314159, 271828`.
Episodes: 60 total.

| Version | Success rate | Capture rate | Mean stable time | Edge-risk rate |
|---|---:|---:|---:|---:|
| v8 | 55.0% | 98.3% | 7.206s | 28.3% |
| v9 accepted | **68.3%** | **100.0%** | 7.805s | 31.7% |

## Legacy replay spot check

Scenario mix: previous broad/edge/near/down-ish replay.
Seeds: `60606, 70421, 81131, 424242, 110, 221`.
Episodes: 36 total.

| Version | Success rate | Capture rate | Mean stable time | Edge-risk rate |
|---|---:|---:|---:|---:|
| v8 | 63.9% | 97.2% | 6.981s | 36.1% |
| v9 accepted | **72.2%** | 94.4% | 7.030s | **22.2%** |

## Rejected candidates

Several candidates were rejected even when they improved one subset:

- Global widened state3 capture: improved focused replay slightly but regressed legacy replay.
- Stronger early edge guard: reduced some rail excursions but reduced strict stable success.
- Source1 forced escape: helped a few low-state1 starts but reduced capture in mid-random cases.
- Explicit strong collinearity scoring: often trapped the system near the wrong low-energy basin.
- More aggressive post-training database: improved a small focused sample but increased edge risk and hurt low-state1 consistency.

v9 is therefore the accepted success-priority compromise: it raises aggregate actual success across the focused, broader, and legacy test suites while keeping the previous terminal stabilizer and AI phase-advice integration intact.
