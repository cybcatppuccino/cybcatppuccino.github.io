# State3 specialized AI report — v9

This package is the v9 actual-success build. It keeps oldver as the default controller and only activates the specialized state3 AI branch when:

- target is state 3;
- maxAcc is within 20 ± 5.9;
- gravity is within 9 ± 1.2;
- windAmp is within 0.03 ± 0.10;
- friction is within 0.03 ± 0.10.

v9 focuses on actual success rate across random low-energy, moderate-random, near-state3, and legacy replay starts. The biggest accepted change is a low-energy state0→state3 two-pulse escape that preserves support reserve before the existing state3 stabilizer takes over.

See `ACTUAL_MODEL_EVAL_V9.md` for the replay comparison and `AI_CHANGES_V9.md` for code-level changes.
