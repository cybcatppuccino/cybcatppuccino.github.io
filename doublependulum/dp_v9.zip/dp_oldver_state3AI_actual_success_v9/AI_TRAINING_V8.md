# v8 AI training notes

Training continued from the v7 database and focused on the default-index ±10% state3 specialty.

Command used for the accepted database update:

```bash
python3 train_ai.py \
  --episodes 200 \
  --seconds 12 \
  --dt 0.018 \
  --seed 8808 \
  --validate-episodes 40 \
  --validate-every 100 \
  --validation-seed 70707 \
  --targets 3 \
  --specialties default_index10_state3 \
  --hard-pool-episodes 48 \
  --hard-refresh-every 100 \
  --hard-probes 3 \
  --save-every 200
```

The trainer accepted the intermediate database because validation improved:

- Baseline validation: macro-success 82.5%, capture 85.0%, edge 15.0%, score 240.88
- Accepted validation: macro-success 87.5%, capture 87.5%, edge 10.0%, score 256.16
- Final unaccepted candidate: macro-success 85.0%, capture 92.5%, edge 15.0%, score 251.30

Therefore the final package uses the accepted database, not the final unaccepted overfit candidate.
