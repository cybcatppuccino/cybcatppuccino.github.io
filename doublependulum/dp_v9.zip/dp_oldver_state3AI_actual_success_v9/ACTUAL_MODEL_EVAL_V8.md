# v8 actual-model evaluation

Evaluation uses real browser controller components:

- `js/controller.js`
- `js/physics.js`
- `js/ai_learning.js`
- `ai_data/training_db.json`

The key acceptance test is actual replay, not only the Python trainer score.

## Focused remote-arrival replay

Settings:

- Target: state 3
- Parameter range: default index ±10%
- Seeds: 70421, 81131, 424242, 110, 221
- Episodes: 10 per seed, 50 total
- Scenario mix: low-speed state0/state1/state2, mid-random, near-state3

| Version | Success rate | Capture rate | Mean stable time | Edge-risk rate |
|---|---:|---:|---:|---:|
| v7 baseline | 54.0% | 100.0% | 6.772s | 36.0% |
| v8 accepted | 70.0% | 98.0% | 7.253s | 26.0% |

Per-seed success comparison:

| Seed | v7 | v8 |
|---:|---:|---:|
| 70421 | 40.0% | 50.0% |
| 81131 | 100.0% | 80.0% |
| 424242 | 30.0% | 80.0% |
| 110 | 50.0% | 70.0% |
| 221 | 50.0% | 70.0% |

v8 is accepted because the aggregate actual-model success improves substantially, the average stable time only increases moderately, and edge-risk decreases.

## Legacy replay spot check

Additional actual-model check:

- Seed: 60606
- Episodes: 20
- Mix: legacy

Result:

- Success rate: 70.0%
- Capture rate: 100.0%
- Mean stable time: 5.837s
- Edge-risk rate: 20.0%

## Important interpretation

The explicit strong-collinearity strategies were rejected. The accepted improvement is conservative: it uses the collinearity observation only where actual replay supported it, namely when starting near state0 with both rods already close in angle and angular velocity. The proven v7 state2 bridge and v6/v7 terminal stabilizer remain the main control path elsewhere.
