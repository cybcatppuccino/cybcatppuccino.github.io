import fs from 'node:fs';
import {performance} from 'node:perf_hooks';
const variant=process.env.VARIANT||'controller_baseline';
const {PendulumController}=await import(`./js/variants/${variant}.js`);
import {adaptiveAI} from './js/ai_learning.js'; import {wasmRollout} from './js/wasm_rollout.js';
import {DEFAULT_PARAMS,TARGETS,makeInitialState,stepRK4Into,angleError,supportEdgeRatio,supportCenterError} from './js/physics.js';
const db=JSON.parse(fs.readFileSync(new URL('./ai_data/training_db.json',import.meta.url),'utf8'));adaptiveAI.importDatabase(db,'manual');await wasmRollout.ready;
const p={...DEFAULT_PARAMS,maxAcc:20,g:9,windAmp:.03,friction:.03},dt=1/360,target=TARGETS[3],duration=Number(process.env.DURATION||18);
function m(s){let e1=angleError(s.th1,Math.PI),e2=angleError(s.th2,Math.PI);return{angle:Math.hypot(e1,e2),speed:Math.hypot(s.om1,s.om2),radial:e1*s.om1+e2*s.om2,edge:supportEdgeRatio(s,p)}}
function q(){return{n:makeInitialState(),a:{},b:{},c:{},k1:{},k2:{},k3:{},k4:{}}}function st(s,c,t,z){let a=c.update(s,p,dt,t);stepRK4Into(s,a,p,t,dt,true,z.n,z.a,z.b,z.c,z.k1,z.k2,z.k3,z.k4);let o=s;s=z.n;z.n=o;return[s,a]}
function start(delay){let s=makeInitialState(),t=0,c=new PendulumController(p),z=q();while(t+1e-12<delay){[s]=st(s,c,t,z);t+=dt}return{s:{...s},t}}
function run(delay){let u=start(delay),s=u.s,t=u.t,t0=t,c=new PendulumController(p),z=q();c.setTarget(3,s);let hand=0,pr=0,ti=0,handTime=null,practicalTime=null,tightTime=null,firstCapture=null,firstLocal=null,best=99,maxEdge=0,edgeDanger=0,sat=0,retry=0,cem=0,lqr=0,esc=0;
 for(let i=0;i<duration/dt;i++){let pe=c.escapeTimer>0,pry=c.retryTimer>0,pp=c.plan.length>0,a;[s,a]=st(s,c,t,z);t+=dt;let x=m(s);best=Math.min(best,x.angle);maxEdge=Math.max(maxEdge,x.edge);if(x.edge>.9)edgeDanger+=dt;if(Math.abs(a)>19)sat+=dt;if(firstCapture===null&&x.angle<.6)firstCapture=t-t0;if(firstLocal===null&&c.localCaptureActive)firstLocal=t-t0;
 let h=x.angle<1.1&&x.speed<6.6&&x.edge<.9&&x.radial<3.2;hand=h?hand+dt:Math.max(0,hand-2*dt);if(handTime===null&&hand>.085)handTime=t-t0;let po=x.angle<.96&&x.speed<5.8&&x.edge<.92&&x.radial<3.4;pr=po?pr+dt:Math.max(0,pr-3*dt);if(practicalTime===null&&pr>.14)practicalTime=t-t0;let to=x.angle<.07&&x.speed<.3&&x.edge<.8;ti=to?ti+dt:0;if(tightTime===null&&ti>.5)tightTime=t-t0;if(pe)esc+=dt;else if(pry)retry+=dt;else if(pp)cem+=dt;else lqr+=dt;}
 return{variant,delay,handTime,practicalTime,tightTime,firstCapture,firstLocal,best,maxEdge,edgeDanger,saturationTime:sat,retryTime:retry,cemTime:cem,lqrTime:lqr,escapeTime:esc};}
const delays=process.argv.slice(2).map(Number);let begin=performance.now(),rows=delays.map(run);console.log(JSON.stringify({variant,elapsed:(performance.now()-begin)/1000,rows},null,2));
