import fs from 'node:fs';
import { performance } from 'node:perf_hooks';
import { PendulumController } from './js/controller.js';
import { adaptiveAI } from './js/ai_learning.js';
import { wasmRollout } from './js/wasm_rollout.js';
import {DEFAULT_PARAMS,TARGETS,makeInitialState,stepRK4Into,angleError,supportEdgeRatio,supportCenterError,totalEnergy,energyAtTarget} from './js/physics.js';
const db=JSON.parse(fs.readFileSync(new URL('./ai_data/training_db.json',import.meta.url),'utf8'));adaptiveAI.importDatabase(db,'manual');await wasmRollout.ready;
const p={...DEFAULT_PARAMS,maxAcc:20,g:9,windAmp:.03,friction:.03},target=TARGETS[3],dt=1/360;
const targetE=energyAtTarget(target,p),eScale=p.g*((p.m1+p.m2)*p.l1+p.m2*p.l2);
function M(s){const e1=angleError(s.th1,Math.PI),e2=angleError(s.th2,Math.PI);return{angle:Math.hypot(e1,e2),speed:Math.hypot(s.om1,s.om2),radial:e1*s.om1+e2*s.om2,edge:supportEdgeRatio(s,p),xerr:supportCenterError(s,p),dE:(totalEnergy(s,p)-targetE)/eScale}}
function scratch(){return {next:makeInitialState(),a:{},b:{},c:{},k1:{},k2:{},k3:{},k4:{}}}
function step(s,c,t,q){const a=c.update(s,p,dt,t);stepRK4Into(s,a,p,t,dt,true,q.next,q.a,q.b,q.c,q.k1,q.k2,q.k3,q.k4);const o=s;s=q.next;q.next=o;return[s,a]}
const delays=Array.from({length:101},(_,i)=>i*0.2), maxDelay=delays.at(-1), starts=[];
{
 let s=makeInitialState(),t=0,idx=0,c=new PendulumController(p),q=scratch();
 while(idx<delays.length){if(t+1e-12>=delays[idx]){starts.push({state:{...s},t});idx++;continue;}[s]=step(s,c,t,q);t+=dt;}
}
function run(start,duration=22){let s={...start.state},t=start.t,c=new PendulumController(p),q=scratch();c.setTarget(3,s);const t0=t,n=Math.round(duration/dt);let best=99,maxEdge=0,hand=0,pract=0,tight=0,handTime=null,practicalTime=null,tightTime=null,firstApproach=null,firstCapture=null,firstTerminal=null,firstLocal=null,firstLocalExit=null,firstRetry=null,firstEdge90=null,firstEdge99=null,localEntries=0,retries=0,edgeHits=0,sat=0,absA=0,cem=0,lqr=0,escape=0,retry=0,prevLocal=false,prevRetry=false,prevEdge99=false,zoneCross=0,lastAboveCapture=true;
 for(let i=0;i<n;i++){
  const preE=c.escapeTimer>0,preR=c.retryTimer>0,preP=c.plan.length>0;let a;[s,a]=step(s,c,t,q);t+=dt;const z=M(s);best=Math.min(best,z.angle);maxEdge=Math.max(maxEdge,z.edge);absA+=Math.abs(a)*dt;if(Math.abs(a)>.95*p.maxAcc)sat+=dt;
  if(z.angle<1.3&&firstApproach===null)firstApproach=t-t0;if(z.angle<.6&&firstCapture===null)firstCapture=t-t0;if(z.angle<.18&&firstTerminal===null)firstTerminal=t-t0;
  if(z.angle<.6&&lastAboveCapture){zoneCross++;lastAboveCapture=false}else if(z.angle>.72)lastAboveCapture=true;
  if(c.localCaptureActive&&!prevLocal){localEntries++;if(firstLocal===null)firstLocal=t-t0} if(!c.localCaptureActive&&prevLocal&&firstLocalExit===null)firstLocalExit=t-t0;prevLocal=c.localCaptureActive;
  if(c.retryTimer>0&&!prevRetry){retries++;if(firstRetry===null)firstRetry=t-t0}prevRetry=c.retryTimer>0;
  const edge99=z.edge>.995;if(edge99&&!prevEdge99)edgeHits++;prevEdge99=edge99;if(z.edge>.90&&firstEdge90===null)firstEdge90=t-t0;if(z.edge>.995&&firstEdge99===null)firstEdge99=t-t0;
  const ho=z.angle<1.10&&z.speed<6.60&&z.edge<.90&&z.radial<3.20;hand=ho?hand+dt:Math.max(0,hand-2*dt);if(handTime===null&&hand>.085)handTime=t-t0;
  const po=z.angle<.96&&z.speed<5.80&&z.edge<.92&&z.radial<3.40;pract=po?pract+dt:Math.max(0,pract-3*dt);if(practicalTime===null&&pract>.14)practicalTime=t-t0;
  const to=z.angle<.07&&z.speed<.30&&z.edge<.80;tight=to?tight+dt:0;if(tightTime===null&&tight>.50)tightTime=t-t0;
  if(preE)escape+=dt;else if(preR)retry+=dt;else if(preP)cem+=dt;else lqr+=dt;
 }
 const f=M(s);return{delay:start.t,handTime,practicalTime,tightTime,firstApproach,firstCapture,firstTerminal,firstLocal,firstLocalExit,firstRetry,firstEdge90,firstEdge99,best,maxEdge,localEntries,retries,edgeHits,zoneCross,saturationTime:sat,meanAbsA:absA/duration,cemTime:cem,lqrTime:lqr,escapeTime:escape,retryTime:retry,finalAngle:f.angle,finalSpeed:f.speed,finalEdge:f.edge};}
const begin=performance.now(),rows=starts.map((s,i)=>{const r=run(s);if((i+1)%10===0)console.error(i+1);return r});
fs.writeFileSync('/mnt/data/state3_mass.json',JSON.stringify({params:p,elapsed:(performance.now()-begin)/1000,rows},null,2));
const keys=Object.keys(rows[0]);fs.writeFileSync('/mnt/data/state3_mass.csv',keys.join(',')+'\n'+rows.map(r=>keys.map(k=>r[k]??'').join(',')).join('\n'));
console.log(JSON.stringify({elapsed:(performance.now()-begin)/1000,n:rows.length},null,2));
