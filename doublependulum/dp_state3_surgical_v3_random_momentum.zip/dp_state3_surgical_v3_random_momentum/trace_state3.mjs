import fs from 'node:fs';
import { PendulumController } from './js/controller.js';
import { adaptiveAI } from './js/ai_learning.js';
import { wasmRollout } from './js/wasm_rollout.js';
import { DEFAULT_PARAMS,TARGETS,makeInitialState,stepRK4Into,angleError,supportEdgeRatio,supportCenterError,totalEnergy,energyAtTarget } from './js/physics.js';
const db=JSON.parse(fs.readFileSync(new URL('./ai_data/training_db.json',import.meta.url),'utf8')); adaptiveAI.importDatabase(db,'manual'); await wasmRollout.ready;
const p={...DEFAULT_PARAMS,maxAcc:20,g:9,windAmp:.03,friction:.03}, target=TARGETS[3], dt=1/360;
const energyScale=p.g*((p.m1+p.m2)*p.l1+p.m2*p.l2), targetE=energyAtTarget(target,p);
function m(s){const e1=angleError(s.th1,Math.PI),e2=angleError(s.th2,Math.PI);return{angle:Math.hypot(e1,e2),speed:Math.hypot(s.om1,s.om2),radial:e1*s.om1+e2*s.om2,edge:supportEdgeRatio(s,p),xerr:supportCenterError(s,p),dE:(totalEnergy(s,p)-targetE)/energyScale,e1,e2}}
let s=makeInitialState(),n=makeInitialState(),t=0;const c=new PendulumController(p);c.setTarget(3,s);const q=[{},{},{},{},{},{},{}];
const rows=[];let prev={zone:'swing',local:c.localCaptureActive,escape:c.escapeTimer>0,retry:c.retryTimer>0,plan:false};
for(let i=0;i<15/dt;i++){
 const before={escape:c.escapeTimer>0,retry:c.retryTimer>0,local:c.localCaptureActive,plan:c.plan.length>0};
 const a=c.update(s,p,dt,t); stepRK4Into(s,a,p,t,dt,true,n,...q); [s,n]=[n,s]; t+=dt;
 const z=m(s),zone=z.angle<.18?'terminal':z.angle<.60?'capture':z.angle<1.30?'approach':'swing';
 const cur={zone,local:c.localCaptureActive,escape:c.escapeTimer>0,retry:c.retryTimer>0,plan:c.plan.length>0};
 const event=[]; for(const k of Object.keys(cur))if(cur[k]!==prev[k])event.push(`${k}:${prev[k]}->${cur[k]}`); prev=cur;
 if(i%6===0||event.length||z.edge>.995)rows.push({t:+t.toFixed(6),x:s.x,vx:s.vx,th1:s.th1,th2:s.th2,om1:s.om1,om2:s.om2,a,...z,zone,branch:before.escape?'escape':before.retry?'retry':before.plan?'cem':'local_or_hold',local:c.localCaptureActive,planLen:c.plan.length,event:event.join(';')});
}
fs.writeFileSync('/mnt/data/state3_trace.csv',Object.keys(rows[0]).join(',')+'\n'+rows.map(r=>Object.values(r).map(v=>typeof v==='string'?JSON.stringify(v):v).join(',')).join('\n'));
console.log(JSON.stringify(rows.filter(r=>r.event||r.edge>.99||Math.abs(r.t-3.7)<.02||Math.abs(r.t-11)<.02),null,2));
