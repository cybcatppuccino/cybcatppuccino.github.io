import fs from 'node:fs';
import { PendulumController } from './js/controller.js';
import { adaptiveAI } from './js/ai_learning.js';
import { wasmRollout } from './js/wasm_rollout.js';
import { DEFAULT_PARAMS,TARGETS,stepRK4Into,angleError,supportEdgeRatio,supportCenterError,totalEnergy,energyAtTarget,supportHalfSpan } from './js/physics.js';
const db=JSON.parse(fs.readFileSync(new URL('./ai_data/training_db.json',import.meta.url),'utf8')); adaptiveAI.importDatabase(db,'trace-random'); await wasmRollout.ready;
const src=JSON.parse(fs.readFileSync(process.env.SOURCE||'/mnt/data/v3_baseline_initial_pilot.json','utf8'));
const id=Number(process.env.ID||17); const rr=src.rows.find(x=>x.id===id); if(!rr)throw new Error('id');
const z=rr.initial; const p={...DEFAULT_PARAMS,maxAcc:20,g:9,windAmp:.03,friction:.03},target=TARGETS[3],dt=1/360;
const energyScale=p.g*((p.m1+p.m2)*p.l1+p.m2*p.l2),targetE=energyAtTarget(target,p),half=supportHalfSpan(p);
function m(s){const e1=angleError(s.th1,Math.PI),e2=angleError(s.th2,Math.PI);const an=Math.hypot(e1,e2);return{angle:an,speed:Math.hypot(s.om1,s.om2),radial:an<1e-9?0:(e1*s.om1+e2*s.om2)/an,edge:supportEdgeRatio(s,p),xerr:supportCenterError(s,p),dE:(totalEnergy(s,p)-targetE)/energyScale,e1,e2,predStop:(supportCenterError(s,p)+Math.sign(s.vx)*s.vx*s.vx/(2*.45*p.maxAcc))/half}}
let s={x:z.x,vx:z.vx,th1:z.th1,th2:z.th2,om1:z.om1,om2:z.om2},n={...s},t=z.t0;const c=new PendulumController(p);c.setTarget(3,s);const q=[{},{},{},{},{},{},{}],rows=[];
let prev={local:c.localCaptureActive,retry:c.retryTimer>0,escape:c.escapeTimer>0,plan:c.plan.length>0};
for(let i=0;i<26/dt;i++){
 const before={local:c.localCaptureActive,retry:c.retryTimer>0,escape:c.escapeTimer>0,plan:c.plan.length>0,cmd:c.commandAcc};
 const a=c.update(s,p,dt,t);stepRK4Into(s,a,p,t,dt,true,n,...q);[s,n]=[n,s];t+=dt;const mm=m(s);const cur={local:c.localCaptureActive,retry:c.retryTimer>0,escape:c.escapeTimer>0,plan:c.plan.length>0};
 const ev=[];for(const k of Object.keys(cur))if(cur[k]!==prev[k])ev.push(`${k}:${prev[k]}->${cur[k]}`);prev=cur;
 if(i%8===0||ev.length||mm.edge>.99||(mm.angle<.7&&mm.speed<8))rows.push({elapsed:t-z.t0,t,x:s.x,vx:s.vx,th1:s.th1,th2:s.th2,om1:s.om1,om2:s.om2,a,...mm,branch:before.escape?'escape':before.retry?'retry':before.plan?'cem':'local',event:ev.join(';')});
}
const out=process.env.OUTPUT||`/mnt/data/trace_random_${id}.csv`;fs.writeFileSync(out,Object.keys(rows[0]).join(',')+'\n'+rows.map(r=>Object.values(r).map(v=>typeof v==='string'?JSON.stringify(v):v).join(',')).join('\n'));
console.log(JSON.stringify({id,initial:z,events:rows.filter(r=>r.event||r.edge>.99||(r.angle<.25&&r.speed<5)).slice(0,120)},null,2));
