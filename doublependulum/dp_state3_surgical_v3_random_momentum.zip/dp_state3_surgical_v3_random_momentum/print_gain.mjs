import {PendulumController} from './js/controller.js';import {DEFAULT_PARAMS,makeInitialState} from './js/physics.js';
const p={...DEFAULT_PARAMS,maxAcc:20,g:9,windAmp:.03,friction:.03};const c=new PendulumController(p);c.setTarget(3,makeInitialState());c.lqrAcceleration(makeInitialState(),p);console.log(c.cachedGain);
