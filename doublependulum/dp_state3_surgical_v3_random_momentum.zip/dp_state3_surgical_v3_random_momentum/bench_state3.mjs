import fs from 'node:fs';
import { performance } from 'node:perf_hooks';
import { PendulumController } from './js/controller.js';
import { adaptiveAI } from './js/ai_learning.js';
import { wasmRollout } from './js/wasm_rollout.js';
import {
  DEFAULT_PARAMS, TARGETS, makeInitialState, stepRK4Into, angleError,
  supportEdgeRatio, supportCenterError
} from './js/physics.js';

const db = JSON.parse(fs.readFileSync(new URL('./ai_data/training_db.json', import.meta.url), 'utf8'));
adaptiveAI.importDatabase(db, 'node-manual');
await wasmRollout.ready;

const DT = 1/360;
const params = {...DEFAULT_PARAMS, maxAcc:20, g:9.0, windAmp:0.03, friction:0.03};
const target = TARGETS[3];

function metrics(s){
  const e1=angleError(s.th1,target.angles[0]), e2=angleError(s.th2,target.angles[1]);
  return {
    angle:Math.hypot(e1,e2), speed:Math.hypot(s.om1,s.om2),
    radial:e1*s.om1+e2*s.om2, edge:supportEdgeRatio(s,params),
    xerr:supportCenterError(s,params)
  };
}
function stepper(){return {next:makeInitialState(),s1:{},s2:{},s3:{},k1:{},k2:{},k3:{},k4:{}}}
function oneStep(state, ctrl, t, st){
  const a=ctrl.update(state,params,DT,t);
  stepRK4Into(state,a,params,t,DT,true,st.next,st.s1,st.s2,st.s3,st.k1,st.k2,st.k3,st.k4);
  const old=state; state=st.next; st.next=old; return [state,a];
}
function preRun(delay){
  let state=makeInitialState(), t=0; const ctrl=new PendulumController(params), st=stepper();
  while(t+1e-12<delay){ [state]=oneStep(state,ctrl,t,st); t+=DT; }
  return {state:{...state},t};
}
function run(delay=0, duration=Number(process.env.DURATION || 20)){
  let {state,t}=preRun(delay); const ctrl=new PendulumController(params); ctrl.setTarget(3,state); const st=stepper();
  const startT=t, n=Math.round(duration/DT);
  let best=Infinity, maxEdge=0, hand=0, practical=0, tight=0;
  let handTime=null, practicalTime=null, tightTime=null;
  let firstApproach=null, firstCapture=null, firstTerminal=null, firstLocal=null;
  let cemTime=0,lqrTime=0,escapeTime=0,retryTime=0;
  let commandAbs=0, saturationTime=0, edgeDangerTime=0, flybyCount=0, prevRadial=null;
  let lastZone='swing', zoneEntries={swing:0,approach:0,capture:0,terminal:0};
  let minAngleState=null;
  for(let i=0;i<n;i++){
    const m0=metrics(state);
    const wasEscape=ctrl.escapeTimer>0, wasRetry=ctrl.retryTimer>0;
    let a; [state,a]=oneStep(state,ctrl,t,st); t+=DT;
    const m=metrics(state); if(m.angle<best){best=m.angle;minAngleState={t:t-startT,...m,a,x:state.x,vx:state.vx,th1:state.th1,th2:state.th2,om1:state.om1,om2:state.om2};}
    maxEdge=Math.max(maxEdge,m.edge); commandAbs+=Math.abs(a)*DT; if(Math.abs(a)>0.95*params.maxAcc)saturationTime+=DT;
    if(m.edge>0.90)edgeDangerTime+=DT;
    const zone=m.angle<0.18?'terminal':m.angle<0.60?'capture':m.angle<1.30?'approach':'swing';
    if(zone!==lastZone){zoneEntries[zone]++; lastZone=zone;}
    if(firstApproach===null&&m.angle<1.30)firstApproach=t-startT;
    if(firstCapture===null&&m.angle<0.60)firstCapture=t-startT;
    if(firstTerminal===null&&m.angle<0.18)firstTerminal=t-startT;
    if(firstLocal===null&&ctrl.localCaptureActive)firstLocal=t-startT;
    const handOk=m.angle<1.10&&m.speed<6.60&&m.edge<0.90&&m.radial<3.20;
    hand=handOk?hand+DT:Math.max(0,hand-2*DT); if(handTime===null&&hand>0.085)handTime=t-startT;
    const practicalOk=m.angle<0.96&&m.speed<5.80&&m.edge<0.92&&m.radial<3.40;
    practical=practicalOk?practical+DT:Math.max(0,practical-3*DT); if(practicalTime===null&&practical>0.14)practicalTime=t-startT;
    const tightOk=m.angle<0.070&&m.speed<0.30&&m.edge<0.80;
    tight=tightOk?tight+DT:0; if(tightTime===null&&tight>0.50)tightTime=t-startT;
    if(prevRadial!==null && prevRadial<0 && m.radial>0 && m.angle<0.64 && m.speed>5.5)flybyCount++;
    prevRadial=m.radial;
    if(wasEscape)escapeTime+=DT; else if(wasRetry)retryTime+=DT; else if(ctrl.plan?.length)cemTime+=DT; else lqrTime+=DT;
  }
  const fin=metrics(state);
  return {delay,handTime,practicalTime,tightTime,firstApproach,firstCapture,firstTerminal,firstLocal,best,maxEdge,edgeDangerTime,saturationTime,meanAbsCommand:commandAbs/duration,flybyCount,zoneEntries,cemTime,lqrTime,escapeTime,retryTime,finalAngle:fin.angle,finalSpeed:fin.speed,finalEdge:fin.edge,minAngleState};
}

const delays=process.argv.slice(2).map(Number); if(!delays.length)delays.push(0);
const t0=performance.now();
const out=delays.map((d,i)=>{const r=run(d); console.error(`done ${i+1}/${delays.length} delay=${d} practical=${r.practicalTime} tight=${r.tightTime}`); return r;});
console.log(JSON.stringify({wasmReady:wasmRollout.isReady(),dbProfiles:adaptiveAI.records.size,dbRules:adaptiveAI.phaseRules.size,elapsedSec:(performance.now()-t0)/1000,results:out},null,2));
