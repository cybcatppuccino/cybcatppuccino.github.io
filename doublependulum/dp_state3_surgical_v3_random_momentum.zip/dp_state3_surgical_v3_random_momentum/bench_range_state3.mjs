import fs from 'node:fs';
import { performance } from 'node:perf_hooks';
import { PendulumController } from './js/controller.js';
import { adaptiveAI } from './js/ai_learning.js';
import { wasmRollout } from './js/wasm_rollout.js';
import {
  DEFAULT_PARAMS, TARGETS, makeInitialState, stepRK4Into, angleError,
  supportEdgeRatio, supportCenterError
} from './js/physics.js';

const db = JSON.parse(fs.readFileSync(new URL('./ai_data/training_db.json', import.meta.url), 'utf8'));
adaptiveAI.importDatabase(db, 'node-range-bench');
await wasmRollout.ready;

const DT = 1 / 360;
const target = TARGETS[3];
const duration = Number(process.env.DURATION || 20);
const mode = process.env.MODE || 'grid';
const output = process.env.OUTPUT || '/mnt/data/state3_range_results.json';

const center = { maxAcc: 20.0, g: 9.0, windAmp: 0.03, friction: 0.03 };
const low = { maxAcc: 14.1, g: 7.8, windAmp: 0.0, friction: 0.0 };
const high = { maxAcc: 25.9, g: 10.2, windAmp: 0.13, friction: 0.13 };

function gridCases() {
  const cases = [{ name: 'center', ...center }];
  for (const key of Object.keys(center)) {
    cases.push({ name: `${key}_low`, ...center, [key]: low[key] });
    cases.push({ name: `${key}_high`, ...center, [key]: high[key] });
  }
  for (let mask = 0; mask < 16; mask++) {
    const p = {};
    const bits = [];
    Object.keys(center).forEach((key, i) => {
      const hi = Boolean(mask & (1 << i));
      p[key] = hi ? high[key] : low[key];
      bits.push(hi ? 'H' : 'L');
    });
    cases.push({ name: `corner_${bits.join('')}`, ...p });
  }
  return cases;
}

function mulberry32(seed) {
  return () => {
    let t = seed += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function randomCases(n = 16) {
  const rnd = mulberry32(0x53a71e3d);
  return Array.from({ length: n }, (_, i) => ({
    name: `random_${String(i + 1).padStart(2, '0')}`,
    maxAcc: low.maxAcc + rnd() * (high.maxAcc - low.maxAcc),
    g: low.g + rnd() * (high.g - low.g),
    windAmp: low.windAmp + rnd() * (high.windAmp - low.windAmp),
    friction: low.friction + rnd() * (high.friction - low.friction),
    delay: rnd() * 8.0
  }));
}

function metrics(s, params) {
  const e1 = angleError(s.th1, target.angles[0]);
  const e2 = angleError(s.th2, target.angles[1]);
  return {
    angle: Math.hypot(e1, e2),
    speed: Math.hypot(s.om1, s.om2),
    radial: e1 * s.om1 + e2 * s.om2,
    edge: supportEdgeRatio(s, params),
    xerr: supportCenterError(s, params)
  };
}
function scratch() {
  return { next: makeInitialState(), s1: {}, s2: {}, s3: {}, k1: {}, k2: {}, k3: {}, k4: {} };
}
function oneStep(state, ctrl, params, t, q) {
  const a = ctrl.update(state, params, DT, t);
  stepRK4Into(state, a, params, t, DT, true, q.next, q.s1, q.s2, q.s3, q.k1, q.k2, q.k3, q.k4);
  const old = state;
  state = q.next;
  q.next = old;
  return [state, a];
}
function preRun(params, delay) {
  let state = makeInitialState();
  // makeInitialState is based on DEFAULT_PARAMS, but the rail geometry is unchanged in this range.
  let t = 0;
  const ctrl = new PendulumController(params);
  const q = scratch();
  while (t + 1e-12 < delay) {
    [state] = oneStep(state, ctrl, params, t, q);
    t += DT;
  }
  return { state: { ...state }, t };
}
function runCase(spec, delay) {
  const params = { ...DEFAULT_PARAMS, maxAcc: spec.maxAcc, g: spec.g, windAmp: spec.windAmp, friction: spec.friction };
  let { state, t } = preRun(params, delay);
  const ctrl = new PendulumController(params);
  ctrl.setTarget(3, state);
  const q = scratch();
  const startT = t;
  const n = Math.round(duration / DT);
  let practicalDwell = 0, tightDwell = 0;
  let practicalTime = null, tightTime = null, firstCapture = null, firstLocal = null;
  let maxEdge = 0, edgeDangerTime = 0, saturationTime = 0, meanAbsA = 0;
  let retries = 0, edgeHits = 0, localEntries = 0;
  let prevRetry = false, prevEdgeHit = false, prevLocal = false;
  let cemTime = 0, lqrTime = 0, retryTime = 0, escapeTime = 0;
  for (let i = 0; i < n; i++) {
    const wasEscape = ctrl.escapeTimer > 0;
    const wasRetry = ctrl.retryTimer > 0;
    const wasPlan = ctrl.plan?.length > 0;
    let a;
    [state, a] = oneStep(state, ctrl, params, t, q);
    t += DT;
    const m = metrics(state, params);
    if (firstCapture === null && m.angle < 0.60) firstCapture = t - startT;
    if (ctrl.localCaptureActive && !prevLocal) {
      localEntries++;
      if (firstLocal === null) firstLocal = t - startT;
    }
    prevLocal = ctrl.localCaptureActive;
    if (ctrl.retryTimer > 0 && !prevRetry) retries++;
    prevRetry = ctrl.retryTimer > 0;
    const edgeHit = m.edge > 0.995;
    if (edgeHit && !prevEdgeHit) edgeHits++;
    prevEdgeHit = edgeHit;
    maxEdge = Math.max(maxEdge, m.edge);
    if (m.edge > 0.90) edgeDangerTime += DT;
    if (Math.abs(a) > 0.95 * params.maxAcc) saturationTime += DT;
    meanAbsA += Math.abs(a) * DT;
    const practicalOk = m.angle < 0.96 && m.speed < 5.80 && m.edge < 0.92 && m.radial < 3.40;
    practicalDwell = practicalOk ? practicalDwell + DT : Math.max(0, practicalDwell - 3 * DT);
    if (practicalTime === null && practicalDwell > 0.14) practicalTime = t - startT;
    const tightOk = m.angle < 0.070 && m.speed < 0.30 && m.edge < 0.80;
    tightDwell = tightOk ? tightDwell + DT : 0;
    if (tightTime === null && tightDwell > 0.50) tightTime = t - startT;
    if (wasEscape) escapeTime += DT;
    else if (wasRetry) retryTime += DT;
    else if (wasPlan) cemTime += DT;
    else lqrTime += DT;
  }
  const f = metrics(state, params);
  const effectiveTight = tightTime ?? duration + 5;
  const score = effectiveTight + 4 * edgeHits + 1.5 * retries + 2.5 * Math.max(0, maxEdge - 0.90) + (tightTime === null ? 12 : 0);
  return {
    case: spec.name, delay, ...params,
    practicalTime, tightTime, firstCapture, firstLocal,
    maxEdge, edgeDangerTime, edgeHits, retries, localEntries,
    saturationTime, meanAbsA: meanAbsA / duration,
    cemTime, lqrTime, retryTime, escapeTime,
    finalAngle: f.angle, finalSpeed: f.speed, finalEdge: f.edge,
    score
  };
}

const cases = mode === 'random' ? randomCases(Number(process.env.N || 16)) : gridCases();
const fixedDelays = (process.env.DELAYS || '0,4.6').split(',').map(Number);
const rows = [];
const t0 = performance.now();
for (let i = 0; i < cases.length; i++) {
  const spec = cases[i];
  const delays = mode === 'random' ? [spec.delay] : fixedDelays;
  for (const delay of delays) rows.push(runCase(spec, delay));
  console.error(`${i + 1}/${cases.length} ${spec.name}`);
}
const summary = {
  n: rows.length,
  tightSuccess: rows.filter(r => r.tightTime !== null).length,
  practicalSuccess: rows.filter(r => r.practicalTime !== null).length,
  edgeHitTrials: rows.filter(r => r.edgeHits > 0).length,
  retryTrials: rows.filter(r => r.retries > 0).length,
  meanScore: rows.reduce((s, r) => s + r.score, 0) / rows.length,
  meanTightSuccessful: (() => { const x = rows.filter(r => r.tightTime !== null); return x.reduce((s,r)=>s+r.tightTime,0)/Math.max(1,x.length); })(),
  center: rows.filter(r => r.case === 'center')
};
const data = { mode, duration, bounds: { low, center, high }, summary, elapsedSec: (performance.now() - t0) / 1000, rows };
fs.writeFileSync(output, JSON.stringify(data, null, 2));
console.log(JSON.stringify(summary, null, 2));
