import fs from 'node:fs';
import { performance } from 'node:perf_hooks';
import { PendulumController } from './js/controller.js';
import { adaptiveAI } from './js/ai_learning.js';
import { wasmRollout } from './js/wasm_rollout.js';
import {
  DEFAULT_PARAMS, TARGETS, stepRK4Into, angleError,
  supportBounds, supportCenter, supportHalfSpan, supportEdgeRatio, supportCenterError
} from './js/physics.js';

const db = JSON.parse(fs.readFileSync(new URL('./ai_data/training_db.json', import.meta.url), 'utf8'));
adaptiveAI.importDatabase(db, 'node-random-initial');
await wasmRollout.ready;

const DT = 1 / 360;
const target = TARGETS[3];
const duration = Number(process.env.DURATION || 26);
const nEach = Number(process.env.N_EACH || 24);
const seed = Number(process.env.SEED || 13791117) >>> 0;
const output = process.env.OUTPUT || '/mnt/data/random_initial_results.json';
const params = { ...DEFAULT_PARAMS, maxAcc: 20, g: 9, windAmp: 0.03, friction: 0.03 };
const bounds = supportBounds(params);
const center = supportCenter(params);
const half = supportHalfSpan(params);

function mulberry32(a) {
  return function() {
    let t = a += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
const rnd = mulberry32(seed);
const uniform = (lo, hi) => lo + (hi - lo) * rnd();
const signedPower = (limit, p=1) => Math.sign(uniform(-1,1)) * limit * Math.pow(rnd(), p);
function clamp(v,lo,hi){ return Math.max(lo,Math.min(hi,v)); }
function wrap(a){ let x=(a+Math.PI)%(2*Math.PI); if(x<0)x+=2*Math.PI; return x-Math.PI; }

function makeCases() {
  const cases=[];
  for (let i=0;i<nEach;i++) {
    // Typical switch from state 0 after arbitrary cart drift/impulse.
    cases.push({
      family:'down_momentum', index:i,
      x: center + signedPower(0.84*half, 0.80),
      vx: signedPower(4.2, 0.78),
      th1: signedPower(0.42, 1.25),
      th2: signedPower(0.42, 1.25),
      om1: signedPower(1.8, 0.90),
      om2: signedPower(1.8, 0.90),
      t0: uniform(0,8)
    });
  }
  for (let i=0;i<nEach;i++) {
    // Capture/handoff stress: near upright, but both support and links carry momentum.
    cases.push({
      family:'capture_momentum', index:i,
      x: center + signedPower(0.88*half, 0.82),
      vx: signedPower(5.0, 0.72),
      th1: wrap(Math.PI + signedPower(0.88, 0.90)),
      th2: wrap(Math.PI + signedPower(0.88, 0.90)),
      om1: signedPower(4.8, 0.78),
      om2: signedPower(4.8, 0.78),
      t0: uniform(0,8)
    });
  }
  for (let i=0;i<nEach;i++) {
    // Broad phase-space coverage, bounded away from immediately impossible rail-stop states.
    cases.push({
      family:'broad_phase', index:i,
      x: center + signedPower(0.80*half, 0.92),
      vx: signedPower(4.4, 0.80),
      th1: uniform(-Math.PI, Math.PI),
      th2: uniform(-Math.PI, Math.PI),
      om1: signedPower(3.8, 0.82),
      om2: signedPower(3.8, 0.82),
      t0: uniform(0,8)
    });
  }
  // Guarantee exact center/default and several symmetric stress anchors are always present.
  cases.unshift(
    {family:'anchor',index:0,x:center,vx:0,th1:0,th2:0,om1:0,om2:0,t0:0},
    {family:'anchor',index:1,x:center-0.65*half,vx:-3.2,th1:0.12,th2:-0.08,om1:0.8,om2:-0.6,t0:2.3},
    {family:'anchor',index:2,x:center+0.65*half,vx:3.2,th1:-0.12,th2:0.08,om1:-0.8,om2:0.6,t0:5.1},
    {family:'anchor',index:3,x:center-0.68*half,vx:-3.6,th1:wrap(Math.PI+0.35),th2:wrap(Math.PI-0.25),om1:2.4,om2:-2.0,t0:1.7},
    {family:'anchor',index:4,x:center+0.68*half,vx:3.6,th1:wrap(Math.PI-0.35),th2:wrap(Math.PI+0.25),om1:-2.4,om2:2.0,t0:6.4}
  );
  return cases;
}
function scratch(state){return {next:{...state},s1:{},s2:{},s3:{},k1:{},k2:{},k3:{},k4:{}};}
function metrics(s){
  const e1=angleError(s.th1,Math.PI),e2=angleError(s.th2,Math.PI);
  return {angle:Math.hypot(e1,e2),speed:Math.hypot(s.om1,s.om2),edge:supportEdgeRatio(s,params),xerr:supportCenterError(s,params),radial:e1*s.om1+e2*s.om2};
}
function runCase(spec,id){
  let state={x:clamp(spec.x,bounds.left+0.02,bounds.right-0.02),vx:spec.vx,th1:spec.th1,th2:spec.th2,om1:spec.om1,om2:spec.om2};
  let t=spec.t0;
  const ctrl=new PendulumController(params); ctrl.setTarget(3,state);
  const q=scratch(state); const steps=Math.round(duration/DT);
  let legacyDwell=0,strictDwell=0,practicalDwell=0;
  let legacyTime=null,strictTime=null,practicalTime=null;
  let maxEdge=0, edgeHits=0,retries=0,localEntries=0,saturationTime=0,absA=0;
  let prevHit=false,prevRetry=false,prevLocal=false;
  let minAngle=1e9,minSpeedAtNear=1e9;
  for(let k=0;k<steps;k++){
    const a=ctrl.update(state,params,DT,t);
    stepRK4Into(state,a,params,t,DT,true,q.next,q.s1,q.s2,q.s3,q.k1,q.k2,q.k3,q.k4);
    const old=state; state=q.next; q.next=old; t+=DT;
    const m=metrics(state);
    if(m.angle<minAngle){minAngle=m.angle;minSpeedAtNear=m.speed;}
    maxEdge=Math.max(maxEdge,m.edge);
    const hit=m.edge>0.995; if(hit&&!prevHit)edgeHits++; prevHit=hit;
    if(ctrl.retryTimer>0&&!prevRetry)retries++; prevRetry=ctrl.retryTimer>0;
    if(ctrl.localCaptureActive&&!prevLocal)localEntries++; prevLocal=ctrl.localCaptureActive;
    if(Math.abs(a)>0.95*params.maxAcc)saturationTime+=DT; absA+=Math.abs(a)*DT;
    const pOk=m.angle<0.96&&m.speed<5.8&&m.edge<0.92&&m.radial<3.4;
    practicalDwell=pOk?practicalDwell+DT:Math.max(0,practicalDwell-3*DT);
    if(practicalTime===null&&practicalDwell>0.14)practicalTime=t-spec.t0;
    const lOk=m.angle<0.070&&m.speed<0.30&&m.edge<0.80;
    legacyDwell=lOk?legacyDwell+DT:0;
    if(legacyTime===null&&legacyDwell>0.50)legacyTime=t-spec.t0;
    const sOk=m.angle<0.060&&m.speed<0.25&&m.edge<0.78&&Math.abs(state.vx)<0.42;
    strictDwell=sOk?strictDwell+DT:0;
    if(strictTime===null&&strictDwell>0.65)strictTime=t-spec.t0;
  }
  const f=metrics(state);
  const score=(strictTime??duration+10)+5*edgeHits+1.5*retries+8*(strictTime===null?1:0)+3*Math.max(0,maxEdge-0.90);
  return {id,family:spec.family,index:spec.index,initial:{...spec},practicalTime,legacyTime,strictTime,maxEdge,edgeHits,retries,localEntries,saturationTime,meanAbsA:absA/duration,minAngle,minSpeedAtNear,finalAngle:f.angle,finalSpeed:f.speed,finalEdge:f.edge,finalVx:state.vx,score};
}
function summarize(rows){
  const families=[...new Set(rows.map(r=>r.family))];
  const sumGroup=x=>({n:x.length,practical:x.filter(r=>r.practicalTime!==null).length,legacy:x.filter(r=>r.legacyTime!==null).length,strict:x.filter(r=>r.strictTime!==null).length,edgeHitTrials:x.filter(r=>r.edgeHits>0).length,retryTrials:x.filter(r=>r.retries>0).length,meanStrictSuccessful:(()=>{const y=x.filter(r=>r.strictTime!==null);return y.reduce((s,r)=>s+r.strictTime,0)/Math.max(1,y.length)})(),medianStrictSuccessful:(()=>{const y=x.filter(r=>r.strictTime!==null).map(r=>r.strictTime).sort((a,b)=>a-b);return y.length?y[Math.floor(y.length/2)]:null})(),meanScore:x.reduce((s,r)=>s+r.score,0)/Math.max(1,x.length)});
  return {all:sumGroup(rows),byFamily:Object.fromEntries(families.map(f=>[f,sumGroup(rows.filter(r=>r.family===f))]))};
}
const allCases=makeCases();
const filterIds = String(process.env.FILTER_IDS || '').split(',').map(x=>x.trim()).filter(Boolean).map(Number).filter(Number.isInteger);
const selectedCases = filterIds.length
  ? filterIds.filter(i=>i>=0 && i<allCases.length).map(i=>({spec:allCases[i], id:i}))
  : allCases.map((spec,id)=>({spec,id}));
const rows=[]; const t0=performance.now();
for(let i=0;i<selectedCases.length;i++){
  const item=selectedCases[i]; rows.push(runCase(item.spec,item.id));
  if((i+1)%10===0||i===selectedCases.length-1)console.error(`${i+1}/${selectedCases.length}`);
}
const data={seed,nEach,duration,params,strictDefinition:{angle:0.060,speed:0.25,edge:0.78,vx:0.42,dwell:0.65},summary:summarize(rows),elapsedSec:(performance.now()-t0)/1000,rows};
fs.writeFileSync(output,JSON.stringify(data,null,2)); console.log(JSON.stringify(data.summary,null,2));
