# AI Data Directory

`training_db.json` is the offline training database used by the adaptive AI.

In this package, the browser is inference-only by default: it reads this JSON file and does not overwrite it with local browser training.

Continue training forever from the existing database:

```bash
python train_ai.py
```

Train a finite number of episodes:

```bash
python train_ai.py --episodes 1000
```

Evaluate without changing the database:

```bash
python train_ai.py --eval-only --validate-episodes 160
```

After training, serve the project through a local HTTP server so the browser can load the JSON file:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000/`.
