# Training guide

## Default continuous training

Run this locally from the project folder:

```bash
python train_ai.py
```

This runs continuously, resumes from `ai_data/training_db.json`, uses the specialized curriculum, mines hard cases when enabled, and publishes only when validation accepts the result.

## Finite training run

```bash
python train_ai.py --episodes 1000
```

## Plateau / hard-case training

When ordinary training plateaus, use hard-case mining:

```bash
python train_ai.py --episodes 600 --hard-mining-rate 0.34 --hard-pool-episodes 192 --hard-probes 14
```

This mines failures from browser-like validation states and tries bounded local profile surgery.  The public database is still protected by the validation gate.

For faster experiments:

```bash
python train_ai.py --episodes 300 --seconds 10 --dt 0.01 --validate-episodes 130
```

## Train selected specialties

```bash
python train_ai.py --episodes 600 --specialties windy,extreme_wind,low_g_normal_acc
```

Available names:

```text
default_play, high_acc, low_acc, low_g_low_acc, low_g_normal_acc, high_g,
large_friction, very_large_friction, low_friction_high_acc, windy,
extreme_wind, low_acc_high_friction, high_acc_high_friction
```

## Evaluation only

```bash
python train_ai.py --eval-only --validate-episodes 130 --seconds 10 --dt 0.01
```

A stronger robustness check:

```bash
python train_ai.py --eval-only --validate-episodes 260 --seconds 10 --dt 0.01
```

## Scoring philosophy

The success definition is practical browser handoff: a short dwell inside a broad, safe capture basin that the terminal local controller can quickly stabilize.

The score includes:

- macro success across specialties;
- worst-specialty floor;
- capture rate;
- settling/handoff time;
- mean best angle;
- edge-risk and wrong-energy penalties;
- timeout and specialty-spread penalties.

## Browser use

The browser does not train by default.  Serve the folder:

```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000/
```

The page loads:

```text
ai_data/training_db.json
```

and uses the included trained profiles/rules directly.
