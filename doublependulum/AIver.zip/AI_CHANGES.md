# AI changes in this build

## 1. Plateau handling: hard-case mining added

`train_ai.py` now includes a hard-case mining path for plateau stages.  Instead of only sampling new random episodes, it can mine browser-like validation failures, replay those exact difficult states, and try bounded local profile changes before accepting them.

New options:

```bash
python train_ai.py --hard-mining-rate 0.34 --hard-pool-episodes 192 --hard-probes 14
```

The default continuous trainer keeps this available, but still protects the published database with the validation gate.

## 2. Handoff success definition

The success criterion has been made closer to the browser goal: if the system spends a short dwell time inside a broad, safe, low-speed capture basin, it counts as a successful handoff to the local stabilizer.  This avoids rejecting cases that are already practically recoverable but have not yet reached near-zero angle/rate in the offline window.

## 3. Faster capture controller in the trainer

The offline policy was retuned for faster approach before the local stabilizer takes over:

- approach zone now uses more target-alignment authority;
- far swing-up now includes a small alignment term instead of pure energy pumping;
- rail mixing starts slightly earlier but less aggressively, reducing edge failures without over-centering.

These changes are intentionally conservative and validation-gated.

## 4. Specialized curriculum retained

The trainer still uses named web-facing regimes rather than broad random slider sampling:

```text
default_play, high_acc, low_acc, low_g_low_acc, low_g_normal_acc,
high_g, large_friction, very_large_friction, low_friction_high_acc,
windy, extreme_wind, low_acc_high_friction, high_acc_high_friction
```

## 5. Parameter-specialized phase rules retained

Phase rules continue to be separated by parameter regime suffixes:

- `pa...` acceleration regime
- `pg...` gravity regime
- `pf...` friction regime
- `pw...` wind regime

This prevents high-acceleration, low-gravity, high-friction, and high-wind advice from overwriting default play advice.

## 6. Browser still uses static trained results

Browser online learning remains disabled by default:

```js
const BROWSER_ONLINE_LEARNING_ENABLED = false;
const USE_BROWSER_LOCAL_AI_CACHE = false;
```

The browser directly loads `ai_data/training_db.json` and uses the included learned profiles/rules.

## 7. Included validation result

Using the updated browser-handoff evaluation protocol with all 13 specialties:

| Metric | Uploaded dpAI baseline | New package |
|---|---:|---:|
| Profiles | 678 | 678 |
| Phase rules | 2153 | 2153 |
| Macro success / handoff | 66.9% | 74.6% |
| Worst-specialty success | 30.0% | 50.0% |
| Edge-risk rate | 16.2% | 11.5% |
| Balanced score | 94.85 | 111.25 |

Additional 260-episode check:

| Metric | New package |
|---|---:|
| Macro success / handoff | 71.9% |
| Worst-specialty success | 60.0% |
| Edge-risk rate | 11.5% |
| Balanced score | 111.68 |

Note: extra database updates were attempted after this retune, but the validation gate rejected them because they reduced the all-specialty score. The published database therefore keeps the best accepted learned profiles/rules while the code now contains the stronger plateau-training mechanism for future runs.
